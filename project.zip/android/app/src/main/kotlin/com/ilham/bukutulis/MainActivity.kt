package com.ilham.bukutulis

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
