import 'package:flutter/material.dart';
// Import Google Mobile Ads package
import 'package:google_mobile_ads/google_mobile_ads.dart';
// Import SharedPreferences for local storage
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  // Ensure Flutter engine is initialized before plugins
  WidgetsFlutterBinding.ensureInitialized();
  // Initialize AdMob SDK
  MobileAds.instance.initialize();

  // Run the main app widget directly
  runApp(const MaterialApp(
    title: 'Buku Tulis',
    home: BukuTulisScreen(),
  ));
}

// Stateful widget for the writing screen
class BukuTulisScreen extends StatefulWidget {
  const BukuTulisScreen({super.key});

  @override
  State<BukuTulisScreen> createState() => _BukuTulisScreenState();
}

class _BukuTulisScreenState extends State<BukuTulisScreen> {
  BannerAd? _bannerAd;
  bool _isLoaded = false;
  // Variable to hold error message for debugging
  String _adStatus = 'Memuat Iklan...';

  // Controller to handle text input
  final TextEditingController _noteController = TextEditingController();

  // Your ACTUAL Ad Unit ID
  final String adUnitId = 'ca-app-pub-9612303412210729/6660641331';

  @override
  void initState() {
    super.initState();
    // Load the ad and saved notes on startup
    _loadAd();
    _loadSavedNote();
  }

  // Load saved text from local storage
  Future<void> _loadSavedNote() async {
    final prefs = await SharedPreferences.getInstance();
    final savedText = prefs.getString('saved_note') ?? '';
    setState(() {
      _noteController.text = savedText;
    });
  }

  // Save text to local storage
  Future<void> _saveNote(String text) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('saved_note', text);
  }

  void _loadAd() {
    _bannerAd = BannerAd(
      adUnitId: adUnitId,
      request: const AdRequest(),
      size: AdSize.banner,
      listener: BannerAdListener(
        onAdLoaded: (ad) {
          setState(() {
            _isLoaded = true;
            _adStatus = 'Iklan Berhasil Dimuat';
          });
        },
        onAdFailedToLoad: (ad, err) {
          // Show the exact error message on the screen
          setState(() {
            _adStatus = 'Error Iklan: ${err.message} (Kode: ${err.code})';
          });
          // Dispose ad to free resources
          ad.dispose();
        },
      ),
    )..load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Buku Tulis'),
        actions: [
          // Delete button to clear note
          IconButton(
            icon: const Icon(Icons.delete_outline),
            onPressed: () {
              _noteController.clear();
              _saveNote('');
            },
          ),
        ],
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: TextField(
                controller: _noteController,
                maxLines: null, // Allow infinite scrolling
                keyboardType: TextInputType.multiline,
                onChanged: (text) {
                  // Auto-save when typing
                  _saveNote(text);
                },
                decoration: const InputDecoration(
                  hintText: 'Mulai menulis cerita Anda di sini...',
                  border: InputBorder.none,
                ),
              ),
            ),
          ),
          // Debugging UI: Show the ad if loaded, otherwise show the status/error text
          Container(
            padding: const EdgeInsets.all(8.0),
            color: Colors.grey[200],
            child: _isLoaded && _bannerAd != null
                ? SafeArea(
                    child: SizedBox(
                      width: _bannerAd!.size.width.toDouble(),
                      height: _bannerAd!.size.height.toDouble(),
                      child: AdWidget(ad: _bannerAd!),
                    ),
                  )
                : SafeArea(
                    child: Text(
                      _adStatus,
                      style: const TextStyle(color: Colors.red, fontSize: 12),
                      textAlign: TextAlign.center,
                    ),
                  ),
          )
        ],
      ),
    );
  }

  @override
  void dispose() {
    // Clean up resources
    _bannerAd?.dispose();
    _noteController.dispose();
    super.dispose();
  }
}
